/*
 * MonitorESXDatastoreCapacity.java
 *
 * Created on Sep 29, 2008
 *
 * The purpose of this extension is to allow users to threshold datastore capacities on ESX hosts.
 * 
 */

package com.uptimesoftware.uptime.erdc;
import com.uptimesoftware.uptime.erdc.baseclass.*;
import com.uptimesoftware.uptime.erdc.perfcheck.MonitorPerformanceCheckDataRetriever;
import com.uptimesoftware.uptime.erdc.performance.statistics.*;
import com.uptimesoftware.uptime.base.entity.UptimeHostIdByHostnameLoader;
import com.uptimesoftware.uptime.base.entity.configuration.MemorySizeByHostLoader;
import com.uptimesoftware.uptime.base.util.Parameters;
import com.uptimesoftware.uptime.erdc.performance.FSData;
import java.util.*;
import java.io.*;


/**
 *
 * @author Kenneth Cheung [ken.cheung@uptimesoftware.com]
 */
public class MonitorESXDatastoreCapacity extends Monitor {
    
    /*
    private String hostname         = "";
    private Double freeMem          = null;
    private Double freeSwap         = null;
    private Double freeMemPercent     = null;
    private Long physicalMem        = null;
    */
    
    /** Creates a new instance of MonitorPerformance */
    public MonitorESXDatastoreCapacity() {
    }
    
    @Override
    public void setParameters(Parameters params, Long instanceId) {
        super.setParameters(params, instanceId);
    }
    
    protected void monitor(){
        
        try {
            
            MemorySizeByHostLoader memoryLoader = new MemorySizeByHostLoader();
            UptimeHostIdByHostnameLoader idLoader = new UptimeHostIdByHostnameLoader();            
            MonitorPerformanceCheckDataRetriever retriever = new MonitorPerformanceCheckDataRetriever();
            
            idLoader.setHostname(getHostname());                        
            Long hostId = idLoader.execute();
            memoryLoader.setHostId(hostId);
            DataSample  dataSample      = retriever.getMostRecentDataSample(getHostname());
            //Aggregate   dataAggregate   = dataSample.getAggregate();                        
            
            List myDiskList = dataSample.getDisks();
            List<FilesystemCapacity> myDiskList2 = dataSample.getFilesystems();
         
            /* Debug code leave in for testing
            BufferedWriter logger = new BufferedWriter(new FileWriter("c:\\MonitorPerformance.txt"));
            logger.write("Running! ------   ");
            logger.write("The collection has " + myDiskList2.size() + " objects");
            */ 

            ListIterator li = myDiskList2.listIterator();
            
            //declare some variables to get this show started
            double worstFsCapacity = 0;
            double thisFsCap = 0;
            String worstFileSystemName = null;
            
            //Forward direction traversal of all elemints in the list
             while(li.hasNext()){
                 
             FilesystemCapacity myFSCAP = (FilesystemCapacity) li.next();
             
             /* Debug code 
             logger.write(myFSCAP.getFilesystem()+ " " +myFSCAP.getPercentUsed().toString() + "% ");
              */  
                
             thisFsCap = Double.parseDouble(myFSCAP.getPercentUsed().toString());
                
             //myFSCAP.getFilesystem().toString()
             if (worstFsCapacity < thisFsCap){ 
                 worstFsCapacity = myFSCAP.getPercentUsed();
                 worstFileSystemName = myFSCAP.getFilesystem();
             }
          
             }
            
             addVariable("worstOffenderFSCapacity", worstFsCapacity);
             setMessage("The most filled ESX datastore filesystem is: " + worstFileSystemName + " with a capacity of " + worstFsCapacity + "%" );
             setStatus("TBD");
             
             /* Test Output For Debugging
             logger.write("\nWorst FS:" + worstFileSystemName + "Worst FS Capacity: " + worstFsCapacity );
             logger.close();
             */
            
            
        } catch(Exception e) {
            setMessage("An error occured while executing the monitor\n" + e.getMessage());
            setStatus("CRIT");
        }
    }
}